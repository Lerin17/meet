Nearo Rounded features five high-contrast font styles and thick and thin round shapes making this font unique.

LICENSE: This font is a DEMO VERSION and ONLY allowed for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- If you want to buy the Cyber ​​Graph commercial license you can go to the following link: https://digitypestudio.com/nearo-rounded-complete-family/

- or can contact me via email:
hello.digitypestudio@gmail.com

- Any donations are very appreciated. Paypal account for donation :
paypal.me/yusufnikisyahroni / nikiartpay@gmail.com

Our Official Website:
https://digitypestudio.com/

Thank You